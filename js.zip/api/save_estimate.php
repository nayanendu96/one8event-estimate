<?php
header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$payload = json_decode(file_get_contents('php://input'), true);

if (!is_array($payload)) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid JSON payload']);
    exit;
}

$id = isset($payload['id']) ? preg_replace('/[^a-f0-9]/', '', strtolower((string) $payload['id'])) : '';
$data = isset($payload['data']) ? $payload['data'] : null;

if (!is_array($data)) {
    http_response_code(400);
    echo json_encode(['error' => 'Missing estimate data']);
    exit;
}

$companyName = isset($payload['company_name']) ? trim((string) $payload['company_name']) : '';
$projectType = isset($payload['project_type']) ? trim((string) $payload['project_type']) : '';
$grandTotal = isset($payload['grand_total']) ? (float) $payload['grand_total'] : 0;

$conn = estimate_db_connect();

if (!$conn) {
    http_response_code(500);
    echo json_encode(['error' => 'Database connection failed']);
    exit;
}

estimate_ensure_table($conn);

if (!estimate_has_items($data)) {
    if ($id !== '') {
        estimate_soft_delete($conn, $id);
    }

    $conn->close();
    echo json_encode([
        'success' => true,
        'skipped' => true,
        'deleted' => $id !== '',
    ]);
    exit;
}

if ($id === '') {
    $id = bin2hex(random_bytes(8));
}

$lockStmt = $conn->prepare('SELECT is_locked FROM estimates WHERE id = ? AND is_deleted = 0');

if ($lockStmt) {
    $lockStmt->bind_param('s', $id);
    $lockStmt->execute();
    $lockResult = $lockStmt->get_result();
    $lockRow = $lockResult ? $lockResult->fetch_assoc() : null;
    $lockStmt->close();

    if ($lockRow && (int) $lockRow['is_locked'] === 1) {
        http_response_code(403);
        echo json_encode(['error' => 'Estimate is locked']);
        $conn->close();
        exit;
    }
}

$jsonData = json_encode($data, JSON_UNESCAPED_UNICODE);

if ($jsonData === false) {
    http_response_code(400);
    echo json_encode(['error' => 'Could not encode estimate data']);
    $conn->close();
    exit;
}

$stmt = $conn->prepare(
    'UPDATE estimates
     SET data = ?, company_name = ?, project_type = ?, grand_total = ?
     WHERE id = ? AND is_deleted = 0'
);

if (!$stmt) {
    http_response_code(500);
    echo json_encode(['error' => 'Query preparation failed']);
    $conn->close();
    exit;
}

$stmt->bind_param('sssds', $jsonData, $companyName, $projectType, $grandTotal, $id);
$stmt->execute();

if ($stmt->affected_rows === 0) {
    $insert = $conn->prepare(
        'INSERT INTO estimates (id, data, company_name, project_type, grand_total)
         VALUES (?, ?, ?, ?, ?)'
    );

    if (!$insert) {
        http_response_code(500);
        echo json_encode(['error' => 'Insert preparation failed']);
        $stmt->close();
        $conn->close();
        exit;
    }

    $insert->bind_param('ssssd', $id, $jsonData, $companyName, $projectType, $grandTotal);
    $insert->execute();
    $insert->close();
}

$stmt->close();
$conn->close();

echo json_encode([
    'success' => true,
    'id' => $id,
]);
