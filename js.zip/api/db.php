<?php

$db_host = 'localhost';
$db_name = 'one8_estimates';
$db_user = 'root';
$db_pass = '';

function estimate_db_connect()
{
    global $db_host, $db_name, $db_user, $db_pass;

    $conn = new mysqli($db_host, $db_user, $db_pass, $db_name);

    if ($conn->connect_error) {
        return null;
    }

    $conn->set_charset('utf8mb4');

    return $conn;
}

function estimate_app_url($path)
{
    $path = ltrim(trim((string) $path), '/');

    if ($path === '' || strpos($path, '://') !== false || strpos($path, '..') !== false) {
        $path = 'estimates.php';
    }

    $base = rtrim(dirname(dirname($_SERVER['SCRIPT_NAME'])), '/\\');

    if ($base === '' || $base === '.') {
        return '/' . $path;
    }

    return $base . '/' . $path;
}

function estimate_share_url($id)
{
    $path = estimate_app_url('index.php?id=' . rawurlencode((string) $id));
    $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';

    return $scheme . '://' . $host . $path;
}

function estimate_has_items(array $data)
{
    if (empty($data['groups']) || !is_array($data['groups'])) {
        return false;
    }

    foreach ($data['groups'] as $group) {
        if (empty($group['items']) || !is_array($group['items'])) {
            continue;
        }

        foreach ($group['items'] as $item) {
            foreach (['name', 'description', 'size', 'qty', 'unit', 'rate'] as $field) {
                if (trim((string) ($item[$field] ?? '')) !== '') {
                    return true;
                }
            }
        }
    }

    return false;
}

function estimate_ensure_table($conn)
{
    $sql = 'CREATE TABLE IF NOT EXISTS estimates (
        id VARCHAR(32) NOT NULL PRIMARY KEY,
        data JSON NOT NULL,
        company_name VARCHAR(255) DEFAULT NULL,
        project_type VARCHAR(255) DEFAULT NULL,
        grand_total DECIMAL(15,2) DEFAULT 0,
        is_locked TINYINT(1) NOT NULL DEFAULT 0,
        is_deleted TINYINT(1) NOT NULL DEFAULT 0,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_updated (updated_at DESC)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4';

    if (!$conn->query($sql)) {
        return false;
    }

    $columnCheck = $conn->query("SHOW COLUMNS FROM estimates LIKE 'is_locked'");

    if ($columnCheck && $columnCheck->num_rows === 0) {
        $conn->query('ALTER TABLE estimates ADD COLUMN is_locked TINYINT(1) NOT NULL DEFAULT 0 AFTER grand_total');
    }

    $deletedCheck = $conn->query("SHOW COLUMNS FROM estimates LIKE 'is_deleted'");

    if ($deletedCheck && $deletedCheck->num_rows === 0) {
        $conn->query('ALTER TABLE estimates ADD COLUMN is_deleted TINYINT(1) NOT NULL DEFAULT 0 AFTER is_locked');
    }

    return true;
}

function estimate_ensure_item_table($conn)
{
    $hiddenCheck = $conn->query("SHOW COLUMNS FROM estimate_item LIKE 'is_hidden'");

    if ($hiddenCheck && $hiddenCheck->num_rows === 0) {
        $conn->query('ALTER TABLE estimate_item ADD COLUMN is_hidden TINYINT(1) NOT NULL DEFAULT 0 AFTER d2c_rate');
    }

    return true;
}

function estimate_soft_delete($conn, $id)
{
    $stmt = $conn->prepare(
        'UPDATE estimates
         SET is_deleted = 1
         WHERE id = ? AND is_locked = 0 AND is_deleted = 0'
    );

    if (!$stmt) {
        return false;
    }

    $stmt->bind_param('s', $id);
    $stmt->execute();
    $deleted = $stmt->affected_rows > 0;
    $stmt->close();

    return $deleted;
}
