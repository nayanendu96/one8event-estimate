(function () {
    'use strict';

    var categories = window.estimateCategories || [];
    var estimateId = window.estimateId || '';
    var estimateData = window.estimateData || {};
    var isLocked = !!window.estimateLocked;
    var isManager = !!window.estimateIsManager;
    var savedDiscount = '0';
    var GST_RATE = 0.18;
    var rateMode = 'b2b';
    var discountEditing = false;
    var isRestoring = false;
    var saveTimer = null;
    var DEFAULT_DOCUMENT_TITLE = 'Estimate by ONE8 EVENT X';

    var ones = [
        '', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten',
        'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'
    ];
    var tens = [
        '', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'
    ];

    function escapeHtml(text) {
        var div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    function escapeAttr(text) {
        return String(text)
            .replace(/&/g, '&amp;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;');
    }

    function parseAmount(value) {
        var num = parseFloat(String(value || '').replace(/,/g, '').trim());

        return isNaN(num) ? 0 : num;
    }

    function uppercaseInput(input) {
        if (!input || input.readOnly) {
            return;
        }

        var value = input.value;
        var upper = value.toUpperCase();

        if (value === upper) {
            return;
        }

        var start = input.selectionStart;
        var end = input.selectionEnd;

        input.value = upper;

        if (start !== null && end !== null) {
            input.setSelectionRange(start, end);
        }
    }

    function formatAmount(num) {
        return String(Math.round(num));
    }

    function twoDigits(num) {
        if (num < 20) {
            return ones[num];
        }

        return tens[Math.floor(num / 10)] + (num % 10 ? ' ' + ones[num % 10] : '');
    }

    function threeDigits(num) {
        var result = '';

        if (num >= 100) {
            result += ones[Math.floor(num / 100)] + ' Hundred';
            num %= 100;

            if (num) {
                result += ' ';
            }
        }

        if (num) {
            result += twoDigits(num);
        }

        return result;
    }

    function numberToWordsIndian(num) {
        num = Math.round(Math.abs(num));

        if (num === 0) {
            return 'Zero Rupees And Zero Paisa Only.';
        }

        var parts = [];
        var crore = Math.floor(num / 10000000);

        num %= 10000000;

        var lakh = Math.floor(num / 100000);

        num %= 100000;

        var thousand = Math.floor(num / 1000);

        num %= 1000;

        if (crore) {
            parts.push(threeDigits(crore) + ' Crore');
        }

        if (lakh) {
            parts.push(twoDigits(lakh) + ' Lakh');
        }

        if (thousand) {
            parts.push(twoDigits(thousand) + ' Thousand');
        }

        if (num) {
            parts.push(threeDigits(num));
        }

        return parts.join(' ') + ' Rupees And Zero Paisa Only.';
    }

    function buildCategorySelect() {
        var options = '<option value="">Select Category</option>';

        categories.forEach(function (category) {
            options += '<option value="' + category.id + '">' + escapeHtml(category.name) + '</option>';
        });

        return '<select class="categorySelect">' + options + '</select>';
    }

    function resizeItemNameField(field) {
        if (!field || !field.classList.contains('itemNameInput')) {
            return;
        }

        field.style.height = 'auto';
        field.style.height = field.scrollHeight + 'px';
    }

    function resizeAllItemNameFields(root) {
        var scope = root || document;

        scope.querySelectorAll('.itemNameInput').forEach(resizeItemNameField);
    }

    function buildItemRow() {
        var rateCell =
                '<td class="manager-hidden"><div class="inpBx"><input type="text" placeholder="" class="txtfld itemRateInput"/></div></td>' +
                '<td class="manager-hidden"><div class="inpBx"><input type="text" placeholder="" class="txtfld itemAmtInput" readonly/></div></td>' +
                '<td class="manager-hidden">&nbsp;</td>';

        return (
            '<tr class="item-row">' +
                '<td><div class="inpBx itemNameWrap">' +
                    '<textarea rows="1" placeholder="" class="txtfld itemNameInput" autocomplete="off"></textarea>' +
                    '<div class="itemSuggestList"></div>' +
                '</div></td>' +
                '<td><div class="inpBx"><input type="text" placeholder="" class="txtfld"/></div></td>' +
                '<td><div class="inpBx"><input type="text" placeholder="" class="txtfld"/></div></td>' +
                '<td><div class="inpBx"><input type="text" placeholder="" class="txtfld itemSqftInput"/></div></td>' +
                '<td><div class="inpBx"><input type="text" placeholder="" class="txtfld itemUnitInput"/></div></td>' +
                rateCell +
                '<td class="no-print"><span class="closeBtn" title="Delete Row">Close</span></td>' +
            '</tr>'
        );
    }

    function getRowAllFields(row) {
        var cells = row.querySelectorAll('td');

        return {
            name: row.querySelector('.itemNameInput'),
            description: cells[1] ? cells[1].querySelector('.txtfld') : null,
            size: cells[2] ? cells[2].querySelector('.txtfld') : null,
            sqft: row.querySelector('.itemSqftInput'),
            unit: row.querySelector('.itemUnitInput'),
            rate: row.querySelector('.itemRateInput'),
            amt: row.querySelector('.itemAmtInput')
        };
    }

    function getRowFields(row) {
        return {
            name: row.querySelector('.itemNameInput'),
            sqft: row.querySelector('.itemSqftInput'),
            unit: row.querySelector('.itemUnitInput'),
            rate: row.querySelector('.itemRateInput'),
            amt: row.querySelector('.itemAmtInput')
        };
    }

    function getRowAmount(row) {
        var amtInput = row.querySelector('.itemAmtInput');

        return amtInput ? parseAmount(amtInput.value) : 0;
    }

    function calculateRowAmount(row) {
        var fields = getRowFields(row);

        if (!fields.sqft || !fields.rate || !fields.amt) {
            return 0;
        }

        var sqft = parseAmount(fields.sqft.value);
        var rate = parseAmount(fields.rate.value);

        if (sqft > 0 && rate > 0) {
            var amount = sqft * rate;
            fields.amt.value = formatAmount(amount);
            return amount;
        }

        fields.amt.value = '';
        return 0;
    }

    function updateGroupSubtotal(group) {
        var total = 0;

        group.querySelectorAll('tr.item-row').forEach(function (row) {
            total += getRowAmount(row);
        });

        var subtotalEl = group.querySelector('.group-subtotal');

        if (subtotalEl) {
            subtotalEl.textContent = formatAmount(total);
        }

        return total;
    }

    function updateDiscountRowVisibility(table, discount) {
        var discountRow = table.querySelector('.discount-row');
        var subtotalRow = table.querySelector('.subtotal-row');
        var wordsEl = table.querySelector('.amount-in-words');
        var addDiscountBtn = table.querySelector('.addDiscountBtn');
        var hasDiscount = discount > 0 || discountEditing;

        if (discountRow) {
            discountRow.classList.toggle('is-hidden', !hasDiscount);
        }

        if (subtotalRow) {
            subtotalRow.classList.toggle('is-hidden', !hasDiscount);
        }

        if (wordsEl) {
            wordsEl.rowSpan = hasDiscount ? 5 : 3;
        }

        if (addDiscountBtn) {
            addDiscountBtn.classList.toggle('is-hidden', hasDiscount);
        }
    }

    function showDiscountRow(table) {
        var discountRow = table.querySelector('.discount-row');
        var discountInput = table.querySelector('.discountInput');

        discountEditing = true;
        updateDiscountRowVisibility(table, parseAmount(discountInput ? discountInput.value : 0));

        if (discountInput) {
            discountInput.focus();
            discountInput.select();
        }
    }

    function calculateEstimateTotals(table) {
        var estimateTotal = 0;

        table.querySelectorAll('tbody.estimate-group').forEach(function (group) {
            group.querySelectorAll('tr.item-row').forEach(function (row) {
                calculateRowAmount(row);
            });
            estimateTotal += updateGroupSubtotal(group);
        });

        var discountInput = table.querySelector('.discountInput');
        var discount = discountInput ? parseAmount(discountInput.value) : parseAmount(savedDiscount);
        var subTotal = Math.max(0, estimateTotal - discount);
        var gst = Math.round(subTotal * GST_RATE);

        return {
            estimateTotal: estimateTotal,
            discount: discount,
            subTotal: subTotal,
            gst: gst,
            grandTotal: subTotal + gst
        };
    }

    function updateFooterTotals(table) {
        var totals = calculateEstimateTotals(table);

        var totalEl = table.querySelector('.estimate-total');
        var subTotalEl = table.querySelector('.estimate-subtotal');
        var gstEl = table.querySelector('.estimate-gst');
        var grandTotalEl = table.querySelector('.estimate-grand-total');
        var wordsEl = table.querySelector('.amount-in-words');

        if (totalEl) {
            totalEl.textContent = formatAmount(totals.estimateTotal);
        }

        if (subTotalEl) {
            subTotalEl.textContent = formatAmount(totals.subTotal);
        }

        if (gstEl) {
            gstEl.textContent = formatAmount(totals.gst);
        }

        if (grandTotalEl) {
            grandTotalEl.textContent = formatAmount(totals.grandTotal);
        }

        if (wordsEl) {
            wordsEl.textContent = numberToWordsIndian(totals.grandTotal);
        }

        updateDiscountRowVisibility(table, totals.discount);
        scheduleSave(table);
    }

    function collectState(table) {
        var groups = [];

        table.querySelectorAll('tbody.estimate-group').forEach(function (group) {
            var select = group.querySelector('.categorySelect');
            var items = [];

            group.querySelectorAll('tr.item-row').forEach(function (row) {
                var fields = getRowAllFields(row);

                items.push({
                    name: fields.name ? fields.name.value : '',
                    description: fields.description ? fields.description.value : '',
                    size: fields.size ? fields.size.value : '',
                    qty: fields.sqft ? fields.sqft.value : '',
                    unit: fields.unit ? fields.unit.value : '',
                    rate: fields.rate ? fields.rate.value : '',
                    selectedItem: row._selectedItem || null
                });
            });

            groups.push({
                categoryId: select ? select.value : '',
                items: items
            });
        });

        var discountInput = table.querySelector('.discountInput');
        var discount = discountInput ? discountInput.value : savedDiscount;
        var projectTypeInput = document.querySelector('.projectTypeInput');
        var companyNameInput = document.querySelector('.companyNameInput');
        var projectOwnerInput = document.querySelector('.projectOwnerInput');
        var eventDateInput = document.querySelector('.eventDateInput');

        return {
            rateMode: rateMode,
            discount: discount,
            discountVisible: discountEditing || parseAmount(discount) > 0,
            header: {
                projectType: projectTypeInput ? projectTypeInput.value : '',
                companyName: companyNameInput ? companyNameInput.value : '',
                projectOwner: projectOwnerInput ? projectOwnerInput.value : '',
                eventDate: eventDateInput ? eventDateInput.value : ''
            },
            groups: groups
        };
    }

    function hasSavableItems(state) {
        if (!state || !Array.isArray(state.groups)) {
            return false;
        }

        return state.groups.some(function (group) {
            if (!Array.isArray(group.items)) {
                return false;
            }

            return group.items.some(function (item) {
                return ['name', 'description', 'size', 'qty', 'unit', 'rate'].some(function (field) {
                    return String(item[field] || '').trim() !== '';
                });
            });
        });
    }

    function fillItemRow(row, itemData) {
        var fields = getRowAllFields(row);
        var data = itemData || {};

        if (fields.name) {
            fields.name.value = data.name || '';
            resizeItemNameField(fields.name);
        }

        if (fields.description) {
            fields.description.value = data.description || '';
        }

        if (fields.size) {
            fields.size.value = data.size || '';
        }

        if (fields.sqft) {
            fields.sqft.value = data.qty || '';
        }

        if (fields.unit) {
            fields.unit.value = data.unit || '';
        }

        if (fields.rate) {
            fields.rate.value = data.rate || '';
        }

        if (data.selectedItem) {
            row._selectedItem = data.selectedItem;
        } else {
            row._selectedItem = null;
        }
    }

    function buildEstimateGroupFromData(groupData) {
        var items = groupData && Array.isArray(groupData.items) && groupData.items.length
            ? groupData.items
            : [{}];
        var rowsHtml = items.map(function () {
            return buildItemRow();
        }).join('');

        var tbody = document.createElement('tbody');
        tbody.className = 'estimate-group';
        tbody.innerHTML =
            '<tr>' +
                '<th colspan="7">' +
                    '<div class="secHdrT1">' + buildCategorySelect() + '</div>' +
                '</th>' +
                '<th class="manager-hidden"><div class="secHdrT2"><span class="tclr02 group-subtotal">0</span></div></th>' +
                '<th class="no-print"><span class="closeBtnGroup" title="Delete Group">Close</span></th>' +
            '</tr>' +
            rowsHtml +
            '<tr class="add-row-tr no-print">' +
                '<td colspan="9">' +
                    '<div class="adRowBtnBx">' +
                        '<span class="addRowBtn">Add Row</span>' +
                    '</div>' +
                '</td>' +
            '</tr>';

        var select = tbody.querySelector('.categorySelect');

        if (select && groupData && groupData.categoryId) {
            select.value = groupData.categoryId;
        }

        var itemRows = tbody.querySelectorAll('tr.item-row');

        items.forEach(function (item, index) {
            fillItemRow(itemRows[index], item);
        });

        return tbody;
    }

    function applyState(data, table) {
        if (!data || !Object.keys(data).length) {
            return;
        }

        isRestoring = true;

        try {
            if (data.header) {
                var projectTypeInput = document.querySelector('.projectTypeInput');
                var companyNameInput = document.querySelector('.companyNameInput');
                var projectOwnerInput = document.querySelector('.projectOwnerInput');
                var eventDateInput = document.querySelector('.eventDateInput');

                if (projectTypeInput) {
                    projectTypeInput.value = data.header.projectType || '';
                }

                if (companyNameInput) {
                    companyNameInput.value = data.header.companyName || '';
                }

                if (projectOwnerInput) {
                    projectOwnerInput.value = data.header.projectOwner || '';
                }

                if (eventDateInput) {
                    eventDateInput.value = data.header.eventDate || '';
                }
            }

            discountEditing = !!data.discountVisible;
            savedDiscount = data.discount || '0';

            var discountInput = table.querySelector('.discountInput');

            if (discountInput) {
                discountInput.value = data.discount || '0';
            }

            if (data.groups && data.groups.length) {
                table.querySelectorAll('tbody.estimate-group').forEach(function (group) {
                    group.remove();
                });

                var addGroupRow = getAddGroupRow(table);

                data.groups.forEach(function (groupData) {
                    table.insertBefore(buildEstimateGroupFromData(groupData), addGroupRow);
                });
            }

            setRateMode(data.rateMode || 'b2b', table);
            updateFooterTotals(table);
            updateDocumentTitle();
        } finally {
            isRestoring = false;
        }
    }

    function updateEstimateUrl(id) {
        var nextUrl = id ? 'index.php?id=' + encodeURIComponent(id) : 'index.php';

        if (window.location.pathname.indexOf('index.php') !== -1) {
            history.replaceState(null, '', nextUrl);
        }
    }

    function handleSaveResponse(result) {
        if (!result || !result.success) {
            return;
        }

        if (result.deleted) {
            estimateId = '';
            updateEstimateUrl('');
            return;
        }

        if (result.skipped) {
            return;
        }

        if (result.id && result.id !== estimateId) {
            estimateId = result.id;
            updateEstimateUrl(estimateId);
        }
    }

    function saveEstimate(table) {
        if (isRestoring || isLocked) {
            return;
        }

        var state = collectState(table);
        var hasItems = hasSavableItems(state);

        if (!hasItems && !estimateId) {
            return;
        }

        var grandTotalEl = table.querySelector('.estimate-grand-total');
        var grandTotal = grandTotalEl
            ? parseAmount(grandTotalEl.textContent)
            : calculateEstimateTotals(table).grandTotal;

        fetch('api/save_estimate.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                id: estimateId,
                data: state,
                company_name: state.header.companyName,
                project_type: state.header.projectType,
                grand_total: grandTotal
            })
        })
            .then(function (response) {
                return response.json();
            })
            .then(function (result) {
                handleSaveResponse(result);
            })
            .catch(function () {});
    }

    function scheduleSave(table) {
        if (isRestoring || isLocked) {
            return;
        }

        if (saveTimer) {
            clearTimeout(saveTimer);
        }

        saveTimer = setTimeout(function () {
            saveEstimate(table);
        }, 500);
    }

    function getActiveItemRate(item) {
        if (!item) {
            return '';
        }

        if (rateMode === 'd2c') {
            return item.d2c_rate || '';
        }

        return item.b2b_rate || '';
    }

    function updateRateToggleUI() {
        document.querySelectorAll('.rateToggleBtn').forEach(function (button) {
            button.classList.toggle('is-active', button.getAttribute('data-rate-mode') === rateMode);
        });
    }

    function refreshSelectedItemRates(table) {
        if (!table) {
            return;
        }

        table.querySelectorAll('tr.item-row').forEach(function (row) {
            if (!row._selectedItem) {
                return;
            }

            var rateInput = row.querySelector('.itemRateInput');

            if (rateInput) {
                rateInput.value = getActiveItemRate(row._selectedItem);
            }

            calculateRowAmount(row);
        });

        updateFooterTotals(table);
    }

    function setRateMode(mode, table) {
        rateMode = mode === 'd2c' ? 'd2c' : 'b2b';
        updateRateToggleUI();
        refreshSelectedItemRates(table);
        scheduleSave(table);
    }

    function recalculateFromRow(row, table) {
        calculateRowAmount(row);
        updateFooterTotals(table);
    }

    var suggestTimer = null;
    var activeSuggestInput = null;
    var suggestRequestId = 0;

    function closeAllSuggestLists() {
        document.querySelectorAll('.itemSuggestList.is-open').forEach(function (list) {
            list.classList.remove('is-open');
            list.innerHTML = '';
        });
        activeSuggestInput = null;
    }

    function applyItemSelection(row, item, table) {
        var fields = getRowFields(row);

        if (!fields.name) {
            return;
        }

        fields.name.value = (item.item_name || '').toUpperCase();
        resizeItemNameField(fields.name);

        if (fields.unit) {
            fields.unit.value = (item.unit || '').toUpperCase();
        }

        if (fields.rate) {
            fields.rate.value = getActiveItemRate(item);
        }

        row._selectedItem = item;

        recalculateFromRow(row, table);
    }

    function renderSuggestList(listEl, items) {
        if (!items.length) {
            listEl.classList.remove('is-open');
            listEl.innerHTML = '';
            return;
        }

        var html = '';

        items.forEach(function (item) {
            html +=
                '<button type="button" class="itemSuggestOption" data-item-id="' + item.id + '" title="' + escapeAttr(item.item_name) + '">' +
                    escapeHtml(item.item_name) +
                '</button>';
        });

        listEl.innerHTML = html;
        listEl.classList.add('is-open');

        listEl.querySelectorAll('.itemSuggestOption').forEach(function (option, index) {
            option._itemData = items[index];
        });
    }

    function fetchItemSuggestions(input) {
        var query = input.value.trim();
        var wrap = input.closest('.itemNameWrap');
        var listEl = wrap ? wrap.querySelector('.itemSuggestList') : null;
        var requestId = ++suggestRequestId;

        if (!listEl) {
            return;
        }

        if (query === '') {
            listEl.classList.remove('is-open');
            listEl.innerHTML = '';
            return;
        }

        fetch('api/search_items.php?q=' + encodeURIComponent(query))
            .then(function (response) {
                return response.json();
            })
            .then(function (items) {
                if (requestId !== suggestRequestId || activeSuggestInput !== input) {
                    return;
                }

                if (!Array.isArray(items)) {
                    renderSuggestList(listEl, []);
                    return;
                }

                renderSuggestList(listEl, items);
            })
            .catch(function () {
                if (requestId === suggestRequestId) {
                    renderSuggestList(listEl, []);
                }
            });
    }

    function handleItemNameInput(input) {
        resizeItemNameField(input);

        var row = input.closest('tr.item-row');

        if (row) {
            row._selectedItem = null;
        }

        activeSuggestInput = input;

        if (suggestTimer) {
            clearTimeout(suggestTimer);
        }

        suggestTimer = setTimeout(function () {
            fetchItemSuggestions(input);
        }, 250);
    }

    function buildEstimateGroup() {
        var tbody = document.createElement('tbody');
        tbody.className = 'estimate-group';
        tbody.innerHTML =
            '<tr>' +
                '<th colspan="7">' +
                    '<div class="secHdrT1">' + buildCategorySelect() + '</div>' +
                '</th>' +
                '<th class="manager-hidden"><div class="secHdrT2"><span class="tclr02 group-subtotal">0</span></div></th>' +
                '<th class="no-print"><span class="closeBtnGroup" title="Delete Group">Close</span></th>' +
            '</tr>' +
            buildItemRow() +
            '<tr class="add-row-tr no-print">' +
                '<td colspan="9">' +
                    '<div class="adRowBtnBx">' +
                        '<span class="addRowBtn">Add Row</span>' +
                    '</div>' +
                '</td>' +
            '</tr>';

        return tbody;
    }

    function getAddGroupRow(table) {
        return table.querySelector('tbody.add-group-row');
    }

    function addGroup(table) {
        var addGroupRow = getAddGroupRow(table);

        if (!addGroupRow) {
            return;
        }

        table.insertBefore(buildEstimateGroup(), addGroupRow);
        updateFooterTotals(table);
    }

    function addRow(groupTbody, table) {
        var addRowTr = groupTbody.querySelector('tr.add-row-tr');

        if (!addRowTr) {
            return;
        }

        addRowTr.insertAdjacentHTML('beforebegin', buildItemRow());
        updateFooterTotals(table);
    }

    function removeRow(row, table) {
        var groupTbody = row.closest('tbody.estimate-group');

        if (!groupTbody) {
            return;
        }

        var itemRows = groupTbody.querySelectorAll('tr.item-row');

        if (itemRows.length <= 1) {
            return;
        }

        row.remove();
        updateFooterTotals(table);
    }

    function removeGroup(groupTbody, table) {
        var groups = table.querySelectorAll('tbody.estimate-group');

        if (groups.length <= 1) {
            return;
        }

        groupTbody.remove();
        updateFooterTotals(table);
    }

    function sanitizeTitlePart(text) {
        return String(text || '')
            .trim()
            .replace(/[\\/:*?"<>|]/g, '')
            .replace(/\s+/g, ' ');
    }

    function getDocumentTitle() {
        var companyInput = document.querySelector('.companyNameInput');
        var companyName = companyInput ? sanitizeTitlePart(companyInput.value) : '';

        if (!companyName) {
            return DEFAULT_DOCUMENT_TITLE;
        }

        return DEFAULT_DOCUMENT_TITLE + ' ' + companyName;
    }

    function updateDocumentTitle() {
        document.title = getDocumentTitle();
    }

    function bindPrintTitle() {
        window.addEventListener('beforeprint', function () {
            updateDocumentTitle();
        });
    }

    function setLockedUI(locked) {
        isLocked = !!locked;
        document.body.classList.toggle('estimate-locked', isLocked);

        document.querySelectorAll('.txtfld:not(.itemAmtInput)').forEach(function (input) {
            input.readOnly = isLocked;
        });

        document.querySelectorAll('.categorySelect').forEach(function (select) {
            select.disabled = isLocked;
        });

        document.querySelectorAll('.rateToggleBtn').forEach(function (button) {
            button.disabled = isLocked;
        });
    }

    document.addEventListener('DOMContentLoaded', function () {
        document.addEventListener('input', function (event) {
            if (event.target.matches('.txtfld')) {
                uppercaseInput(event.target);
            }

            if (event.target.matches('.itemNameInput')) {
                resizeItemNameField(event.target);
            }

            if (event.target.matches('.companyNameInput')) {
                updateDocumentTitle();
            }

            if (event.target.matches('.projectTypeInput, .projectOwnerInput, .eventDateInput, .companyNameInput')) {
                var tableEl = document.querySelector('.frmTable table');

                if (tableEl) {
                    scheduleSave(tableEl);
                }
            }
        }, true);

        bindPrintTitle();
        updateDocumentTitle();

        var printBtn = document.querySelector('.estimatePrintBtn');

        if (printBtn) {
            printBtn.addEventListener('click', function () {
                updateDocumentTitle();
                resizeAllItemNameFields(document);
                window.print();
            });
        }

        var table = document.querySelector('.frmTable table');

        if (!table) {
            return;
        }

        document.querySelectorAll('.rateToggleBtn').forEach(function (button) {
            button.addEventListener('click', function () {
                if (isLocked) {
                    return;
                }

                setRateMode(button.getAttribute('data-rate-mode'), table);
            });
        });

        updateRateToggleUI();
        applyState(estimateData, table);
        resizeAllItemNameFields(table);
        setLockedUI(isLocked);

        table.addEventListener('change', function (event) {
            if (isLocked) {
                return;
            }

            if (event.target.matches('.categorySelect')) {
                updateFooterTotals(table);
            }
        });

        table.addEventListener('input', function (event) {
            if (isLocked) {
                return;
            }
            if (event.target.matches('.itemNameInput')) {
                handleItemNameInput(event.target);
                return;
            }

            if (event.target.matches('.discountInput')) {
                updateFooterTotals(table);
                return;
            }

            var row = event.target.closest('tr.item-row');

            if (row && event.target.matches('.itemSqftInput, .itemRateInput')) {
                recalculateFromRow(row, table);
            }
        });

        table.addEventListener('focusout', function (event) {
            if (isLocked) {
                return;
            }

            if (!event.target.matches('.discountInput')) {
                return;
            }

            if (parseAmount(event.target.value) === 0) {
                discountEditing = false;
                updateFooterTotals(table);
            }
        });

        table.addEventListener('focusin', function (event) {
            if (isLocked) {
                return;
            }

            if (event.target.matches('.discountInput')) {
                discountEditing = true;
                updateDiscountRowVisibility(table, parseAmount(event.target.value));
                return;
            }

            if (event.target.matches('.itemNameInput') && event.target.value.trim() !== '') {
                activeSuggestInput = event.target;
                fetchItemSuggestions(event.target);
            }
        });

        table.addEventListener('mousedown', function (event) {
            if (isLocked) {
                return;
            }

            var option = event.target.closest('.itemSuggestOption');

            if (!option) {
                return;
            }

            event.preventDefault();

            var wrap = option.closest('.itemNameWrap');
            var row = option.closest('tr.item-row');
            var input = wrap ? wrap.querySelector('.itemNameInput') : null;
            var listEl = wrap ? wrap.querySelector('.itemSuggestList') : null;

            if (row && option._itemData) {
                applyItemSelection(row, option._itemData, table);
            }

            if (listEl) {
                listEl.classList.remove('is-open');
                listEl.innerHTML = '';
            }

            if (input) {
                input.focus();
            }

            activeSuggestInput = null;
        });

        document.addEventListener('click', function (event) {
            if (!event.target.closest('.itemNameWrap')) {
                closeAllSuggestLists();
            }
        });

        table.addEventListener('click', function (event) {
            if (isLocked) {
                return;
            }

            var addDiscountBtn = event.target.closest('.addDiscountBtn');

            if (addDiscountBtn) {
                showDiscountRow(table);
                return;
            }

            var addGroupBtn = event.target.closest('.addGrpBtn');

            if (addGroupBtn) {
                addGroup(table);
                return;
            }

            var addRowBtn = event.target.closest('.addRowBtn');

            if (addRowBtn) {
                var groupForRow = addRowBtn.closest('tbody.estimate-group');
                addRow(groupForRow, table);
                return;
            }

            var closeRowBtn = event.target.closest('.closeBtn');

            if (closeRowBtn) {
                removeRow(closeRowBtn.closest('tr.item-row'), table);
                return;
            }

            var closeGroupBtn = event.target.closest('.closeBtnGroup');

            if (closeGroupBtn) {
                removeGroup(closeGroupBtn.closest('tbody.estimate-group'), table);
            }
        });

        updateFooterTotals(table);
        window.addEventListener('beforeunload', function () {
            if (saveTimer) {
                clearTimeout(saveTimer);
                saveEstimate(table);
            }
        });
    });
})();
